/****************************
Company: Eluzini
Product: Eluzini
Developer: Patrick Jesam
patrickikoi@gmail.com
Copyright © 2019 Eluzini
****************************/

/* manage application routes here */
import { RouterModule, Routes, Router } from '@angular/router';
import { ModuleWithProviders } from '@angular/core/src/metadata/ng_module';

/* import application modules */
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './protected/dashboard/dashboard.component';
import { EmployeesComponent } from './protected/employees/employees.component';
import { VisitorsComponent } from './protected/visitors/visitors.component';
import { HomeComponent } from './website/home/home.component';
import { PricingComponent } from './website/pricing/pricing.component';
import { ContactComponent } from './website/contact/contact.component';
import { DepartmentsComponent } from './protected/departments/departments.component';
import { ReportsComponent } from './protected/reports/reports.component';
import { ConversationsComponent } from './protected/conversations/conversations.component';
import { LocationComponent } from './protected/location/location.component';
import { EvacuationComponent } from './protected/evacuation/evacuation.component';

export const AppRoutes: Routes= [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'pricing', component: PricingComponent },
    { path: 'contact', component: ContactComponent },
    { path: 'login', component: LoginComponent },
    { path: 'signup', component: RegisterComponent },
    { path: 'dashboard', component: DashboardComponent },
    { path: 'employees', component: EmployeesComponent },
    { path: 'visitors', component: VisitorsComponent },
    { path: 'departments', component: DepartmentsComponent},
    { path: 'reports', component: ReportsComponent },
    { path: 'conversations', component: ConversationsComponent },
    { path: 'location', component: LocationComponent },
    { path: 'evacuation', component: EvacuationComponent }
];

export const ROUTING: ModuleWithProviders= RouterModule.forRoot(AppRoutes);