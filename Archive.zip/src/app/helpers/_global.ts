/****************************
Company: Eluzini
Product: Eluzini
Developer: Patrick Jesam
patrickikoi@gmail.com
Copyright © 2019 Eluzini
****************************/

import { Injectable, Inject } from '@angular/core';
import { debug } from 'util';

@Injectable()
export class GlobalObjects {
    constructor() { }
}
