/****************************
Company: Eluzini
Product: Eluzini
Developer: Patrick Jesam
patrickikoi@gmail.com
Copyright © 2019 Eluzini
****************************/

import { Component, OnInit } from '@angular/core';
import { GlobalObjects } from '../helpers/_global';

@Component({
    selector: 'app-register',
    templateUrl: './register.component.html',
    styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
    /* global variables */
    public show:boolean;
    public registrationTitle = 'Create Your Eluzini Account';
    /* end global variables */

    constructor(_globalHelpers: GlobalObjects) { }

    ngOnInit() {
    }
    
    next() {
        this.show = true;
        this.registrationTitle = 'Tell us a bit about your workplace';
    }

    back(){
        this.show = false;
        this.registrationTitle = 'Create Your Eluzini Account';
    }
}
