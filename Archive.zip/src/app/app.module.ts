/****************************
Company: Eluzini
Product: Eluzini
Developer: Patrick Jesam
patrickikoi@gmail.com
Copyright © 2019 Eluzini
****************************/

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { GlobalObjects } from './helpers/_global';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ROUTING } from './app.routing';
import { AuthGuardService } from './app.guard';
import { RegisterComponent } from './register/register.component';
import { SidebarComponent } from './partials/sidebar/sidebar.component';
import { DashboardComponent } from './protected/dashboard/dashboard.component';
import { HeaderComponent } from './partials/header/header.component';
import { EmployeesComponent } from './protected/employees/employees.component';
import { VisitorsComponent } from './protected/visitors/visitors.component';
import { HomeComponent } from './website/home/home.component';
import { PricingComponent } from './website/pricing/pricing.component';
import { ContactComponent } from './website/contact/contact.component';
import { DepartmentsComponent } from './protected/departments/departments.component';
import { ConversationsComponent } from './protected/conversations/conversations.component';
import { LocationComponent } from './protected/location/location.component';
import { EvacuationComponent } from './protected/evacuation/evacuation.component';
import { ReportsComponent } from './protected/reports/reports.component';

@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        RegisterComponent,
        SidebarComponent,
        DashboardComponent,
        HeaderComponent,
        EmployeesComponent,
        VisitorsComponent,
        HomeComponent,
        PricingComponent,
        ContactComponent,
        DepartmentsComponent,
        ConversationsComponent,
        LocationComponent,
        EvacuationComponent,
        ReportsComponent
    ],
    imports: [
        BrowserModule,
        ROUTING
    ],
    providers: [AuthGuardService, GlobalObjects],
    bootstrap: [AppComponent]
})
export class AppModule { }
