/****************************
Company: Eluzini
Product: Eluzini
Developer: Patrick Jesam
patrickikoi@gmail.com
Copyright © 2019 Eluzini
****************************/

import { Component, OnInit } from '@angular/core';
import { formatDate } from '@angular/common';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
    /// declare global variables
    initDate = new Date();
    todaysDate;
    constructor() { }

    ngOnInit() {
        this.todaysDate = formatDate(this.initDate, 'dd-MM-yyyy', 'en-US');
    }
}
