/****************************
Company: Eluzini
Product: Eluzini
Developer: Patrick Jesam
patrickikoi@gmail.com
Copyright © 2019 Eluzini
****************************/

import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-employees',
    templateUrl: './employees.component.html',
    styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
    isModalOpen:boolean;

    constructor() { }

    ngOnInit() {
    }

    showModal(){
        this.isModalOpen = true;
    }

    hideModal(){
        this.isModalOpen = false;
    }
}
