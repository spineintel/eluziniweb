import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-evacuation',
  templateUrl: './evacuation.component.html',
  styleUrls: ['./evacuation.component.css']
})
export class EvacuationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
