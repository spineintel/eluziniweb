import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvacuationComponent } from './evacuation.component';

describe('EvacuationComponent', () => {
  let component: EvacuationComponent;
  let fixture: ComponentFixture<EvacuationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvacuationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvacuationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
