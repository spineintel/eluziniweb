import { Injectable, Inject } from "@angular/core";
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
// import { LOCAL_STORAGE, SESSION_STORAGE, WebStorageService } from "angular-webstorage-service";

@Injectable()
export class AuthGuardService implements CanActivate {
    constructor(
        private router: Router
    ){}

    canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ){
        var token = null;
        if(token == null){
            this.router.navigate(["signin"], {
                queryParams: {
                    return: state.url
                }
            })
        }else{
            return false
        }
    }
}